//
//  API.swift
//  Aula 01
//
//  Created by Turma01-10 on 30/08/24.
//

import SwiftUI

struct API: View {
    @StateObject var viewModel = ViewModel()
    
    var body: some View {
        NavigationStack{
            ZStack{
                
                AsyncImage(url :image."https://tavernaderivia.com.br/wp-content/uploads/2023/02/sin.jpg"){
                    phase in
                    switch phase {
                    case .empty:
                        ProgressView()
                    case.sucess(let image):
                        image.resizable()
                            .aspectRatio(contentMode: .fit)
                    case.failure:
                        Image(systemName:"photo")
                    @unknown default:
                        EmptyView()
                    }
                }
                
                
                
                
            }
        }
    }
    
    
    
    #Preview {
        API()
    }
}
