//
//  Parte 2.swift
//  Aula 01
//
//  Created by Turma01-10 on 22/08/24.
//

import SwiftUI

struct Parte_2: View {
   @State private var nome: String="Ruan"
    @State private var mostraAlerta = false
    var body: some View {
        VStack{
            Text("Bem vindo, \(nome)")
                .font(.title)
                
            HStack{
               
                
                TextField("Qual seu nome?",text:$nome)
                    .multilineTextAlignment(.center)
                
            }
            Spacer()
            
            ZStack{
                Image("fundo")
                    .resizable()
                    .frame(width:600.0,height:700.0)
                    .opacity(0.2)
                    
                VStack{
                    Image("logo")
                        .resizable()
                        .frame(width:200.0,height:100.0)
                    
                    
                        .padding()
                    Image("truck")
                        .resizable()
                        .frame(width:200.0,height:100.0)
                    
                    Button("Entrar"){
                        mostraAlerta = true
                        
                    }
                    
                    .alert("Voce ira iniciar o desafio da aula agora",isPresented:$mostraAlerta){}
                
                }
                }
            
            }
            
        }
            
        }
    


#Preview {
    Parte_2()
}
