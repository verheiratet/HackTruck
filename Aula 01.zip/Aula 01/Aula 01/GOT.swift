//
//  GOT.swift
//  Aula 01
//
//  Created by Turma01-10 on 30/08/24.
//

import SwiftUI


    struct hp: Codable, Identifiable {
            let id: String
            let name : String?
            let alternate_names : String?
            let species : String?
            let gender : String?
            let house : String?
            let dateOfBirth : String?
            let yearOfBirth: String?
        let wizard : Bool?
        let ancestry: String?
        let eyeColour: String?
        let hairColour: String?
        let Wand: wand
        let patronous: String?
        let hogwartsStudent: Bool?
        let hogwartsStaff: Bool?
        let actor: String?
        let alternate_actors: [String]?
        let alive: Bool?
        let image: String?
        
        }

struct wand : Codable {
    let wood : String?
    let core : String?
    let length: Double?
}
    



