//
//  SwiftUIView.swift
//  Aula 01
//
//  Created by Turma01-10 on 23/08/24.
//

import SwiftUI

struct Aula 3: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

#Preview {
    SwiftUIView()
}
