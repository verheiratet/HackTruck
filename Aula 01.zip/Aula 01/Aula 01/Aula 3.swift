//
//  Aula 3.swift
//  Aula 01
//
//  Created by Turma01-10 on 23/08/24.
//

import SwiftUI

struct Aula_3: View {
    @State private var Peso :String = ""
    @State private var Altura :String = ""
    @State private var imc :String = ""
    @State private var cor : Color = .white
    
    
    var body: some View {
        ZStack{
            Rectangle()
                .foregroundColor(cor)
            VStack{
                Text("Calculadora de IMC")
                    .font(.title)
                TextField("Qual seu peso?\n",text:$Peso)
                    .clipShape(.capsule)
                    .multilineTextAlignment(.center)
                    .background(.white)
                TextField("Qual sua altura?\n",text:$Altura)
                    .clipShape(.capsule)
                    .multilineTextAlignment(.center)
                    .background(.white)
                
                Button("Calcular"){
                    let Peso1 = Double(Peso)
                    let Altura1 = Double(Altura)
                    
                    let Calculo = (Peso1! / (Altura1! * Altura1!))
                    if (Calculo < 18.5){
                        imc = "Baixo peso"
                        cor = Color("B")
                    }else if(Calculo < 24.99 && Calculo > 18.5){
                        imc = "Normal"
                        cor = Color("N")
                    }else if(Calculo < 29.99 && Calculo > 24.99){
                        imc = "Sobrepeso"
                        cor = Color("Sobrepeso")
                    }else{
                        imc = "Obesidade"
                        cor = Color("Obesidade")
                    }
                        
                        
                
                }
                .foregroundColor(.white)
                .clipShape(.capsule)
                .frame(width:100.0,height:20.0)
                .background(.blue)
                
                
                
                
                Spacer()
                
                Image("imc")
                    .resizable()
                    .frame(width:400.0,height:200.0)
                
            }
        }
    }
}

#Preview {
    Aula_3()
}
