//
//  Aula_01App.swift
//  Aula 01
//
//  Created by Turma01-10 on 21/08/24.
//

import SwiftUI

@main
struct Aula_01App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
