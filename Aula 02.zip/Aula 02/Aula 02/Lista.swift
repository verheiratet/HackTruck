//
//  Lista.swift
//  Aula 02
//
//  Created by Turma01-10 on 26/08/24.
//

import SwiftUI

struct Lista: View {
    var body: some View {
        List{
            
            Text("Rosa")
            Text("Azul")
            Text("Cinza")
        }
    }
}

#Preview {
    Lista()
}
