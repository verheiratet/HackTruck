//
//  Aula_02App.swift
//  Aula 02
//
//  Created by Turma01-10 on 22/08/24.
//

import SwiftUI

@main
struct Aula_02App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
