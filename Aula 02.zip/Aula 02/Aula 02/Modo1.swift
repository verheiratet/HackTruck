//
//  Modo1.swift
//  Aula 02
//
//  Created by Turma01-10 on 26/08/24.
//

import SwiftUI

struct Modo1: View {
    var body: some View {
        NavigationStack{
        
            ZStack{
                    Rectangle()
                        .frame(width: 1000,height: 1000)
                        .foregroundColor(.purple)
                VStack{
                    Text("Modo 1")
                        .font(.title)
                        .foregroundColor(.white)
                    
                    
                    Text("Nome: Philippe \nSobrenome: Facundo")
                        .background(Color.pink)
                        .clipShape(.capsule)
                        .frame(width:500, height:600)
                }
            }
        }
    }
}

#Preview {
    Modo1()
}
