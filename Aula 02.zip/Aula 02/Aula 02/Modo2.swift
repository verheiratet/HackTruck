//
//  Modo2.swift
//  Aula 02
//
//  Created by Turma01-10 on 26/08/24.
//

import SwiftUI

struct Modo2: View {
    var body: some View {
        NavigationStack{
            ZStack{
                Rectangle()
                    .frame(width: 1000,height: 1000)
                    .foregroundColor(.purple)
                Rectangle()
                    .frame(width:300,height:200)
                    .clipShape(.capsule)
                    .foregroundColor(.pink)
                
                VStack{
                    Text("Bem-vindo, Tiago")
                        .font(.title)
                    
                    NavigationLink("Acessar Tela",destination: md2())
                        .foregroundColor(.white)
                        .background(Color.blue)
                        .clipShape(.capsule)
                    
                }
            }
        }
    }
}

#Preview {
    Modo2()
}
