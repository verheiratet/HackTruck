//
//  Azul.swift
//  Aula 02
//
//  Created by Turma01-10 on 26/08/24.
//

import SwiftUI

struct Azul: View {
    var body: some View {
        ZStack{
            Rectangle()
                .frame(width: 1000, height: 1000)
                .foregroundColor(.blue)
            Circle()
                .frame(width:270,height:270)
            
            Image(systemName: "paintbrush.pointed")
                .resizable()
                .frame(width:200,height:200)
                .foregroundColor(.blue)
        }
    }
}

#Preview {
    Azul()
}
