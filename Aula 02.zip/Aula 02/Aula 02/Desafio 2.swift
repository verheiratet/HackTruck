//
//  Desafio 2.swift
//  Aula 02
//
//  Created by Turma01-10 on 26/08/24.
//

import SwiftUI

struct Desafio_2: View {
    var body: some View {
        ZStack{
            
            Rectangle()
                .frame(width: 1000,height: 1000)
                .foregroundColor(.purple)
            VStack{
                
            }
        }
    }
    
    #Preview {
        Desafio_2()
    }
}
