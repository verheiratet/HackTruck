//
//  Desafio2.swift
//  Aula 02
//
//  Created by Turma01-10 on 26/08/24.
//

import SwiftUI
	
struct Desafio2: View {
    @State var shouldPresentSheet = false
    var body: some View {
        NavigationStack{
            ZStack{
                Rectangle()
                    .frame(width: 1000,height: 1000)
                    .foregroundColor(.purple)
                VStack{
                    
                    Image("Image")
                        .resizable()
                        .frame(width:200, height:100)
                    
                    
                    
                    NavigationLink("Modo 1",destination: Modo1())
                    
                        .clipShape(.capsule)
                        .frame(width:150.0,height:60.0)
                        .background(.pink)
                    
                    NavigationLink("Modo 2",destination: Modo2())
                    
                        .clipShape(.capsule)
                        .frame(width:150.0,height:60.0)
                        .background(.pink)
                    
                    Button("Modo 3"){
                        shouldPresentSheet.toggle()
                    }
                    .sheet(isPresented:$shouldPresentSheet){
                        print("Sheet dismissed")
                    }content: {
                        SheetView()
                    }
                    
                    .clipShape(.capsule)
                    .frame(width:150.0,height:60.0)
                    .background(.pink)
                }
            }
        }
    }
    
}
#Preview {
    Desafio2()
}
