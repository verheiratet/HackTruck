//
//  SheetView.swift
//  Aula 02
//
//  Created by Turma01-10 on 26/08/24.
//

import SwiftUI

struct SheetView: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

#Preview {
    SheetView()
}
