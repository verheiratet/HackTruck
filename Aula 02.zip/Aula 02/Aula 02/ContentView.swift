//
//  ContentView.swift
//  Aula 02
//
//  Created by Turma01-10 on 22/08/24.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        
            TabView{
                 Rosa()
                    .tabItem {
                        Label("Rosa", systemImage: "paintbrush")
                            
                        
                    }
                 Azul()
                    .tabItem {
                        Label ("Azul", systemImage: "paintbrush.pointed")
                            
                    }
                
                Cinza()
                    .tabItem {
                        Label ("Cinza", systemImage: "paintpalette")
                            
                    }
                
                Lista()
                    .tabItem {
                        Label ("Lista", systemImage: "list.star")
                            
                    }
                    
                    
        }
            .padding(0)
    }
}

#Preview {
    ContentView()
}
