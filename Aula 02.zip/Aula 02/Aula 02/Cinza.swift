//
//  Cinza.swift
//  Aula 02
//
//  Created by Turma01-10 on 26/08/24.
//

import SwiftUI

struct Cinza: View {
    var body: some View {
        ZStack{
            Rectangle()
                .frame(width: 1000,height:1000)
                .foregroundColor(.gray)
            
            Circle()
                .frame(width:270,height:270)
            
            Image(systemName: "paintpalette")
                .resizable()
                .frame(width:200,height:150)
                .foregroundColor(.gray)
        }
    }
}

#Preview {
    Cinza()
}
