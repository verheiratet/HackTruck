//
//  aa.swift
//  Spotify
//
//  Created by Turma01-10 on 28/08/24.
//

import SwiftUI

struct aa: View {
    var body: some View {
        ZStack{
            Rectangle()
                .fill(Color.gray.gradient)
                .frame(width:395,height:878)
            VStack{
                Image("LucidDreams")
                    .resizable()
                    .frame(width: 200,height:200)
                Text("Lucid Dreams")
                    .font(.title)
                
                HStack{ 
                Image(systemName: "shuffle")
                        .resizable()
                        .frame(width:30,height:30)
                    Image(systemName: "backward.end.fill")
                        .resizable()
                        .frame(width:30,height:30)

                    Image(systemName: "play.fill")
                        .resizable()
                        .frame(width:30,height:30)

                    Image(systemName: "forward.end.fill")
                        .resizable()
                        .frame(width:30,height:30)

                    Image(systemName: "repeat")
                    .resizable()
                    .frame(width:30,height:30)
                    
                }
            }
            
            
        }
    }
}

#Preview {
    aa()
}
