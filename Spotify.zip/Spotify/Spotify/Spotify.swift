//
//  Spotify.swift
//  Spotify
//
//  Created by Turma01-10 on 28/08/24.
//

import SwiftUI

struct Spotify: View {
    var body: some View {
        NavigationStack{
        ZStack{
            Rectangle()
                .fill(Color.gray.gradient)
                .frame(width:395,height:878)
            
            ScrollView{
                VStack(spacing:20){
                    Spacer()
                    Image("LucidDreams")
                    Text("Legends never die")
                        .font(.title)
                    
                    ForEach(arrayMusicas){ Musicas in
                        HStack{
                            Image(Musicas.capa)
                                .resizable()
                                .frame(width:50,height:50)
                            
                            
                                NavigationLink(destination: aa()){
                                    VStack{
                                        Text(Musicas.nome)
                                            .font(.title)
                                        Text(Musicas.artista)}
                                }
                            }
                        }
                    }
                    }
                }
                .frame(height:1000)
                
                
            
                    
                }
                
            }
        }
    

    
    #Preview {
        Spotify()
    }

