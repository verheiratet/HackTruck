//
//  ContentView.swift
//  Spotify
//
//  Created by Turma01-10 on 28/08/24.
//

import SwiftUI

        struct Musicas: Identifiable {
            var id: Int
            var nome: String
            var artista: String
            var capa: String
        }

var arrayMusicas = [
    Musicas(id: 1, nome:"Lucid Dreams", artista:"Juice WRLD", capa:"LucidDreams"),
    Musicas(id: 2, nome:"Righteous", artista:"Juice WRLD", capa:"juice")
]
