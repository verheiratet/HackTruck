//
//  SpotifyApp.swift
//  Spotify
//
//  Created by Turma01-10 on 28/08/24.
//

import SwiftUI

@main
struct SpotifyApp: App {
    var body: some Scene {
        WindowGroup {
            Spotify()
        }
    }
}
